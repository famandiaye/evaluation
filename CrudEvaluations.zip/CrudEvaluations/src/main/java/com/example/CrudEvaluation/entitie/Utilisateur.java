package com.example.CrudEvaluation.entitie;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.management.relation.Role;
import java.util.List;

@Entity
    @Data
    @NoArgsConstructor
    @AllArgsConstructor

    public class Utilisateur {
        @Id
        private Long id;
        private String nom;
        private String prenom;
        private String role;
        private String email;
        private String password;


    }


