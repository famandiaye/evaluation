package com.example.CrudEvaluation.repository;

import com.example.CrudEvaluation.entitie.Deputes;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

public interface DeputesRepository extends JpaRepository<Deputes, Long> {

  // Méthode pour trouver un député par son nom d'utilisateur
  Optional<Deputes> findByUsername(String username);
}

