package com.example.CrudEvaluation.dto;


import lombok.Data;

import java.time.LocalDateTime;

@Data
public class VoteResultatsDTO {
    private Long voteId;        // Identifiant du vote
    private LocalDateTime date; // Date du vote
    private String status;      // État du vote (ouvert/clos)
    private Long totalVotants;  // Nombre total de votants
    private Long oui;           // Nombre de votes "OUI"
    private Long non;           // Nombre de votes "NON"
    private Long abstention;    // Nombre d'abstentions

    // Constructeur
    public VoteResultatsDTO(Long voteId, LocalDateTime date, String status,
                          Long totalVotants, Long oui, Long non, Long abstention) {
        this.voteId = voteId;
        this.date = date;
        this.status = status;
        this.totalVotants = totalVotants;
        this.oui = oui;
        this.non = non;
        this.abstention = abstention;
    }

}

