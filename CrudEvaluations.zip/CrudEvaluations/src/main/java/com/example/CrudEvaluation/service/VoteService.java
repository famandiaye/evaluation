package com.example.CrudEvaluation.service;

import com.example.CrudEvaluation.dto.VoteRequestDTO;
import com.example.CrudEvaluation.dto.VoteResultatsDTO;
import com.example.CrudEvaluation.entitie.Deputes;
import com.example.CrudEvaluation.entitie.Vote;
import com.example.CrudEvaluation.entitie.VoteRecord;
import com.example.CrudEvaluation.repository.DeputesRepository;
import com.example.CrudEvaluation.repository.VoteRepository;
import com.example.CrudEvaluation.repository.VoteRecordRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class VoteService {

    @Autowired
    private VoteRepository voteRepository;

    @Autowired
    private VoteRecordRepository voteRecordRepository;

    @Autowired
    private DeputesRepository deputesRepository; // Ajout du dépôt des députés

    // Créer un nouveau vote
    public Vote createVote(String label) {
        Vote vote = new Vote();
        vote.setLibelle(label);
        vote.setStatus("clos"); // Initialement clos
        vote.setDate(LocalDateTime.now());
        return voteRepository.save(vote);
    }

    // Modifier l'état d'un vote
    public ResponseEntity<?> changeVoteStatus(Long idVote, String username) {
        Optional<Vote> optionalVote = voteRepository.findById(idVote);
        if (optionalVote.isPresent()) {
            Vote vote = optionalVote.get();
            vote.setStatus("clos".equals(vote.getStatus()) ? "ouvert" : "clos");
            voteRepository.save(vote);
            return ResponseEntity.ok(vote);
        }
        return ResponseEntity.status(404).body("Identifiant de vote introuvable!");
    }

    // Trouver tous les votes ouverts
    public List<Vote> findOpenVotes() {
        return voteRepository.findByStatus("ouvert");
    }

    // Enregistrer un vote pour un député
    public ResponseEntity<?> castVote(Long idVote, @Valid VoteRequestDTO voteRequest, String username) {
        Optional<Vote> optionalVote = voteRepository.findById(idVote);
        if (!optionalVote.isPresent()) {
            return ResponseEntity.status(404).body("Identifiant de vote introuvable!");
        }

        Vote vote = optionalVote.get();
        if ("clos".equals(vote.getStatus())) {
            return ResponseEntity.status(403).body("Désolé, le vote est déjà clos !");
        }

        // Vérifier si le député a déjà voté
        if (voteRecordRepository.existsByDeputyIdAndVoteId(getDeputyIdByUsername(username), vote.getId())) {
            return ResponseEntity.status(403).body("Vous avez déjà voté !");
        }

        // Créer et enregistrer le vote
        VoteRecord voteRecord = new VoteRecord();
        voteRecord.setDeputes(getDeputyByUsername(username));
        voteRecord.setVote(vote);
        voteRecord.setChoice(voteRequest.getChoice());
        voteRecordRepository.save(voteRecord);

        return ResponseEntity.status(201).body("Votre vote est bien pris en compte !");
    }

    // Obtenir les résultats d'un vote
    public ResponseEntity<?> getVoteResults(Long id) {
        Optional<Vote> optionalVote = voteRepository.findById(id);
        if (!optionalVote.isPresent() || !"clos".equals(optionalVote.get().getStatus())) {
            return ResponseEntity.status(403).body("Vote introuvable ou non clos !");
        }

        // Calculer les résultats
        Vote vote = optionalVote.get();
        long ouiCount = voteRecordRepository.countByVoteIdAndChoice(vote.getId(), "OUI");
        long nonCount = voteRecordRepository.countByVoteIdAndChoice(vote.getId(), "NON");
        long abstentionCount = voteRecordRepository.countByVoteIdAndChoice(vote.getId(), "ABSTENTION");

        // Retourner les résultats
        return ResponseEntity.ok(new VoteResultatsDTO(vote.getId(), vote.getDate(), vote.getStatus(),
                ouiCount + nonCount + abstentionCount, ouiCount, nonCount, abstentionCount));
    }

    // Méthodes auxiliaires pour obtenir un député par username
    private Deputes getDeputyByUsername(String username) {
        return deputesRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("Député non trouvé avec le nom d'utilisateur : " + username));
    }

    private Long getDeputyIdByUsername(String username) {
        return getDeputyByUsername(username).getId(); // Assurez-vous que cette méthode existe
    }
}
