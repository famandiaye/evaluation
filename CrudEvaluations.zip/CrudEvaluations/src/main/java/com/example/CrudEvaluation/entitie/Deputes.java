package com.example.CrudEvaluation.entitie;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "deputes")
public class Deputes {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id; // Clé primaire

    @Column(nullable = false, unique = true)
    private String username;

    @Column(nullable = false)
    private String firstName;

    @Column(nullable = false)
    private String lastName;

}
