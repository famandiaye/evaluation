package com.example.CrudEvaluation.controller;
import com.example.CrudEvaluation.dto.VoteRequestDTO;
import com.example.CrudEvaluation.service.VoteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.security.Principal;

@RestController
@RequestMapping("/api/vote")
@Validated
public class VoteController {

    @Autowired
    private VoteService voteService;

    // Endpoint pour soumettre un vote
    @PostMapping("/{idVote}/cast")
    public ResponseEntity<?> castVote(@PathVariable Long idVote,
                                      @Valid @RequestBody VoteRequestDTO voteRequest,
                                      Principal principal) {
        // Appeler le service pour traiter le vote
        return voteService.castVote(idVote, voteRequest, principal.getName());
    }

    // Endpoint pour obtenir les résultats d'un vote
    @GetMapping("/{idVote}/results")
    public ResponseEntity<?> getVoteResults(@PathVariable Long idVote, Principal principal) {
        // Vérifier que l'utilisateur est le président
        if (!isPresident(principal)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN)
                    .body("Accès refusé, seule le président peut voir les résultats.");
        }
        // Appeler le service pour obtenir les résultats
        return voteService.getVoteResults(idVote);
    }

    // Méthode utilitaire pour vérifier si l'utilisateur est le président
    private boolean isPresident(Principal principal) {
        // Logique pour déterminer si l'utilisateur est le président
        return "president_username".equals(principal.getName()); // Remplacez par votre logique
    }
}
