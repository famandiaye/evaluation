package com.example.CrudEvaluation.repository;

import com.example.CrudEvaluation.entitie.VoteRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface VoteRecordRepository extends JpaRepository<VoteRecord, Long> {
    // Vérifie si un député a déjà voté pour un scrutin donné
    boolean existsByDeputyIdAndVoteId(Long deputyId, Long voteId);

    // Compte le nombre de votes pour un scrutin et un choix donné
    long countByVoteIdAndChoice(Long voteId, String choice);

    // Méthode pour récupérer tous les votes d'un député (facultatif)
    List<VoteRecord> findByDeputyId(Long deputyId);
}
