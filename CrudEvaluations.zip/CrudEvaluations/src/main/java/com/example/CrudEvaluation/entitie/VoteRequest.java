package com.example.CrudEvaluation.entitie;


import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

public class VoteRequest {

    @NotNull(message = "L'identifiant du vote ne peut pas être nul.")
    private Long voteId;  // Identifiant du vote

    @NotNull(message = "Le choix ne peut pas être nul.")
    @Pattern(regexp = "^(OUI|NON|ABSTENTION)$", message = "Le choix doit être OUI, NON ou ABSTENTION.")
    private String choice; // Choix du député ("OUI", "NON", "ABSTENTION")

    }


