package com.example.CrudEvaluation.dto;

import lombok.Data;

@Data
public class VoteRequestDTO {
    private Long voteId;  // Identifiant du vote
    private String choice; // Choix du député ("OUI", "NON", "ABSTENTION")

    // Constructeur par défaut
    public VoteRequestDTO() {}

    // Constructeur avec paramètres
    public VoteRequestDTO(Long voteId, String choice) {
        this.voteId = voteId;
        this.choice = choice;
    }
}
