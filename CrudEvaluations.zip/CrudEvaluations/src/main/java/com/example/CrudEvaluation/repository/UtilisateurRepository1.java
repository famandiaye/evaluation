package com.example.CrudEvaluation.repository;

import com.example.CrudEvaluation.entitie.Utilisateur;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface UtilisateurRepository1 extends JpaRepository<Utilisateur, Long> {
    Optional<Utilisateur> findByUsername(String username);
}