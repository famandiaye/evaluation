package com.example.CrudEvaluation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudEvaluationApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudEvaluationApplication.class, args);
	}

}
