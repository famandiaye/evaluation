package com.example.CrudEvaluation.dto;

import java.time.LocalDateTime;

public class VoteDTO {
    private Long id;
    private String libelle;

    private String status; // "ouvert" ou "clos"
    private LocalDateTime date;

    // Getters and Setters
}

