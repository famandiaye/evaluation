package com.example.CrudEvaluation.dto;

import lombok.Data;

@Data
public class LoginRequest {
    private String email;
    private String motDePasse;

    // Constructeurs
    public LoginRequest() {}

    public LoginRequest(String email, String motDePasse) {
        this.email = email;
        this.motDePasse = motDePasse;
    }
}
