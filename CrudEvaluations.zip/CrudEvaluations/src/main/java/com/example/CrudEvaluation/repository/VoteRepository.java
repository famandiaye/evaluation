package com.example.CrudEvaluation.repository;

import com.example.CrudEvaluation.entitie.Vote;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface VoteRepository extends JpaRepository<Vote, Long> {
    // Méthode pour trouver tous les votes ouverts
    List<Vote> findByStatus(String status);
}
