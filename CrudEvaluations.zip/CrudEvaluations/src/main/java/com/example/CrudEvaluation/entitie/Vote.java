package com.example.CrudEvaluation.entitie;

import jakarta.persistence.*;

import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor


@Table(name = "votes")
public class Vote {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String libelle; // Intitulé du projet de loi

    @Column(nullable = false)
    private String status; // "ouvert" ou "clos"

    @Column(nullable = false)
    private LocalDateTime date; // Date de création du vote

    @OneToMany(mappedBy = "vote", cascade = CascadeType.ALL)
    private List<VoteRecord> voteRecords; // Liste des votes enregistrés


}

