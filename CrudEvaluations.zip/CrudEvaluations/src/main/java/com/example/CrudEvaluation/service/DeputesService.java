package com.example.CrudEvaluation.service;

public class DeputesService {
}
