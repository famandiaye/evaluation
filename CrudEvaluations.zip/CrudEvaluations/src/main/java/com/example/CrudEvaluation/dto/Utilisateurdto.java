package com.example.CrudEvaluation.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;




import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public class Utilisateurdto {

        private Long id; // Identifiant unique de l'utilisateur
        private String nom; // Nom de l'utilisateur
        private String prenom; // Prénom de l'utilisateur
        private String email; // Email de l'utilisateur
        private String motDePasse; // Mot de passe de l'utilisateur

        private String role; // Rôl
}
