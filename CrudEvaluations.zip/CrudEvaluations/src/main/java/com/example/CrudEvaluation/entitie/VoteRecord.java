package com.example.CrudEvaluation.entitie;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "vote_record")

    public class VoteRecord {

        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private Long id;

        @ManyToOne(optional = false)
        private Deputes deputes; // Référence au député

        @ManyToOne
        @JoinColumn(name = "vote_id", nullable = false)
        private Vote vote; // Référence au vote

        @Column(nullable = false)
        private String choice; // "OUI", "NON", "ABSTENTION"

    }
