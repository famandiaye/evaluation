package com.example.CrudEvaluation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudEvaluationApplicationTests {

	@Test
	void contextLoads() {
	}

}
